#pragma once

#include "Defines.h"
#include "detours.h"
#include "bass.h"
#include "bass_fx.h"

#include <atomic>
#include <thread>
#include <concurrent_queue.h>

//
// proxy ��� ���Ǻ�.
//

BOOL WINAPI 
proxyReadFile(                  HANDLE hFile, 
                                LPVOID lpBuffer, 
                                DWORD nNumberOfBytesToRead, 
                                LPDWORD lpNumberOfBytesRead, 
                                LPOVERLAPPED lpOverlapped);
BOOL WINAPI 
proxyBASS_ChannelPlay(          DWORD handle, 
                                BOOL restart);
BOOL WINAPI 
proxyBASS_ChannelSetPosition(   DWORD handle, 
                                QWORD pos, 
                                DWORD mode);
BOOL WINAPI 
proxyBASS_ChannelSetAttribute(  DWORD handle, 
                                DWORD attrib, 
                                float value);
BOOL WINAPI 
proxyBASS_ChannelPause(         DWORD handle);

#define MAKE_PROXY_DEF(module, function, proxy)             \
    HookEngine<decltype(proxy)> proxy##__hk =               \
    HookEngine<decltype(proxy)>(module, function, proxy)
#define SelectProxy(proxy_class) proxy_class##__hk
#define EngineHook(proxy_class)                             \
    SelectProxy(proxy_class).TryHook()
#define EngineUnhook(proxy_class)                           \
    SelectProxy(proxy_class).Unhook()
#define BeginHook()                                         \
    do                                                      \
    {                                                       \
        DetourTransactionBegin();                           \
        DetourUpdateThread(GetCurrentThread());             \
    } while(0)
#define EndHook() DetourTransactionCommit()

#define NAME_BASS_DLL                   L"bass.dll"
#define NAME_KERNEL_DLL                 L"kernel32.dll"
#define NAME_NAMED_PIPE                 L"\\\\.\\pipe\\osu!Lyrics"
#define AUDIO_FILE_INFO_TOKEN           "AudioFilename:"
#define MAX_MESSAGE_LENGTH              600

template <class funcType>
class HookEngine
{
private:
    funcType* proxy;
    bool isHooked;

public:
    funcType* OriginalFunction;

    HookEngine(const wchar_t *nameModule, const char *nameFunction, funcType* proxy)
    {
        this->OriginalFunction = (funcType*)GetProcAddress(GetModuleHandle(nameModule), nameFunction);
        this->proxy = proxy;
    }
    void TryHook()
    {
        if (!isHooked) this->isHooked = !!DetourAttach(&(PVOID&)OriginalFunction, (PVOID)proxy);
    }
    void Unhook()
    {
        if (isHooked) this->isHooked = !DetourDetach(&(PVOID&)OriginalFunction, (PVOID)proxy);
    }
};

class NamedPipe
{
    HANDLE                                      hEvent;
    HANDLE                                      hPipe;

    std::atomic<bool>                           isThreadRunning;
    std::atomic<bool>                           isPipeConnected;

    void Thread()
    {
        std::wstring wMessage;
        DWORD        nWritten;

        while (isThreadRunning)
        {
            //
            // ConnectNamedPipe�� Ŭ���̾�Ʈ�� �����\ ������ ���� �����:
            // ��Ҵ� DisconnectNamedPipe�� ����
            //
            if (ConnectNamedPipe(hPipe, NULL) || GetLastError() == ERROR_PIPE_CONNECTED)
            {
                isPipeConnected = true;

                if (!ThreadQueues.try_pop(wMessage))
                {
                    WaitForSingleObject(hEvent, 3000);
                    continue;
                }

                if (WriteFile(hPipe, wMessage.c_str(), wMessage.length() * sizeof(std::wstring::value_type), &nWritten, NULL))
                {
                    continue;
                }

                isPipeConnected = false;
                DisconnectNamedPipe(hPipe);
            }
        }

        isPipeConnected = false;
        DisconnectNamedPipe(hPipe);
        CloseHandle(hPipe);
    }

public:

    std::thread*                                ThreadObject;
    concurrency::concurrent_queue<std::wstring> ThreadQueues;

    void Start(const std::wstring&& nPipe)
    {

        hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
        hPipe  = CreateNamedPipeW(

            nPipe.c_str(), 

            PIPE_ACCESS_OUTBOUND, PIPE_TYPE_MESSAGE | PIPE_WAIT, 1, MAX_MESSAGE_LENGTH, 0, INFINITE, NULL);

        isThreadRunning = true;
        
        ThreadObject = new std::thread(&NamedPipe::Thread, this);
        return;
    }

    void Stop()
    {
        isThreadRunning = false;
        ThreadObject->join();

        delete ThreadObject;

        CloseHandle(hEvent);
    }

    void PushMessage(const std::wstring&& message)
    {
        if (!(isPipeConnected & isThreadRunning))
        {
            return;
        }

        ThreadQueues.push(message);
        SetEvent(hEvent);
    }
};